// Constructor
public DigitalVideoDisc(String title, String category, String director, int length, double cost) {
    this.title = title;
    this.category = category;
    this.director = director;
    this.length = length;
    this.cost = cost;
}
