import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public class Cart {
    private List<DigitalVideoDisc> dvds;

    // Constructor
    public Cart() {
        this.dvds = new ArrayList<>();
    }

    // Add DVD to cart
    public void addDVD(DigitalVideoDisc dvd) {
        dvds.add(dvd);
    }

    // Remove DVD from cart
    public void removeDVD(DigitalVideoDisc dvd) {
        dvds.remove(dvd);
    }

    // View all DVDs in the cart
    public void viewCart() {
        for (DigitalVideoDisc dvd : dvds) {
            System.out.println(dvd);
        }
        System.out.println("Total Cost: $" + calculateTotalCost());
    }

    // Calculate total cost of DVDs in the cart
    public double calculateTotalCost() {
        double totalCost = 0;
        for (DigitalVideoDisc dvd : dvds) {
            totalCost += dvd.getCost();
        }
        return totalCost;
    }

    // Sort DVDs by title (alphabetical) and cost (descending)
    public void sortByTitle() {
        dvds.sort(Comparator.comparing(DigitalVideoDisc::getTitle)
                .thenComparing(DigitalVideoDisc::getCost, Comparator.reverseOrder()));
    }

    // Sort DVDs by cost (descending) and title (alphabetical)
    public void sortByCost() {
        dvds.sort(Comparator.comparing(DigitalVideoDisc::getCost).reversed()
                .thenComparing(DigitalVideoDisc::getTitle));
    }

    // Randomly select a DVD to be free
    public DigitalVideoDisc getFreeItem() {
        if (dvds.isEmpty()) {
            return null;
        }
        Random rand = new Random();
        int freeIndex = rand.nextInt(dvds.size());
        return dvds.get(freeIndex);
    }

    // Filter DVDs by title or ID
    public DigitalVideoDisc filterDVDByTitleOrID(String titleOrID) {
        for (DigitalVideoDisc dvd : dvds) {
            if (dvd.getTitle().equalsIgnoreCase(titleOrID) || dvd.getTitle().equalsIgnoreCase(titleOrID)) {
                return dvd;
            }
        }
        System.out.println("Item not found in the current cart.");
        return null;
    }
}
